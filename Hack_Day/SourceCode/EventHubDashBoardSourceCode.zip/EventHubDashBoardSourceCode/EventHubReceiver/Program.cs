﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.ServiceBus.Messaging;
using System.Configuration;

namespace EventHubReceiver
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please make sure the app.config.xml file has the correct azure blob storage key and name.");
            string storageAccountName = ConfigurationManager.AppSettings["storageAccountName"];
            string storageAccountKey = ConfigurationManager.AppSettings["storageAccountKey"];
            Console.WriteLine("Service Bus Connection String to Namespace with RootManageSharedAccessKey:");
            string eventHubConnectionString = Console.ReadLine();
            Console.WriteLine("Name of the event hub to monitor.");
            string eventHubName = Console.ReadLine();
            //string eventHubConnectionString = "Endpoint=sb://brucewaynetollbooth.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=LyWC2gtI/Rui6M1RltgNl3BKYQRICaWqMeqo8niolak=";
            //string eventHubName = "jshub";
            //string storageAccountName = "tweetstreamstor";
            //string storageAccountKey = "oiV/SNCrrdl/VqbWXg5M/47R234Ii6jmfr8mPoprcW9t1RtbjEO4NbEhVpn374eFnFahJki30NzgnLfJ/C8TBQ==";
            string storageConnectionString = string.Format("DefaultEndpointsProtocol=https;AccountName={0};AccountKey={1}",
                        storageAccountName, storageAccountKey);

            string eventProcessorHostName = Guid.NewGuid().ToString();
            EventProcessorHost eventProcessorHost = new EventProcessorHost(eventProcessorHostName, eventHubName, EventHubConsumerGroup.DefaultGroupName, eventHubConnectionString, storageConnectionString);
            eventProcessorHost.RegisterEventProcessorAsync<SimpleEventProcessor>().Wait();

            Console.WriteLine("Receiving. Press enter key to stop worker.");
            Console.ReadLine();
        }
    }
}
