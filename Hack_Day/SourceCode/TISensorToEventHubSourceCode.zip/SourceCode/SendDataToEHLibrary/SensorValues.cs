﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SendDataToEHLibrary
{
    public static class SensorValues
    {
        public static string Humidity { get; set; }
        public static double AmbientTemperature { get; set; }
        public static double TargetTemperature { get; set; }
        public static string body { get; set; }


    }
}
